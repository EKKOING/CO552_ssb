/**
Interface for player classes
@author Nicholas Lorentzen
@version 2019/03/25
*/
public interface Character
{
    public boolean attack();
    public boolean block();

}