/**
Class to run the Super Smash Bros Game
@author Nicholas Lorentzen
@version 2019/03/25
*/
public class SmashGame
{
    public static void main(String[] args) 
    {
        System.out.println("Hello, Would you like to play a game?");
    }
}