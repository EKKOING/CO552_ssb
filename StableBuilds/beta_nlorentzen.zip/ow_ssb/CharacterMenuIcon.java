/**
 * 
 */

/**
 * @author student
 *
 */
public class CharacterMenuIcon {

	/**
	 * 
	 */
	public CharacterMenuIcon() {
		// TODO Auto-generated constructor stub
	}

}
